package interfaz;

import java.awt.EventQueue;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.Timer;

import ejercicio.InterfazSimulator;
import ejercicio.busqueda.informadaConUbeme.ArqueologoConUbeme;
import ejercicio.busqueda.informadaSinUbeme.ArqueologoSinUbeme;
import ejercicio.busqueda.noInformadaEstrategia.ArqueologoEstrategia;
import ejercicio.busqueda.noInformadaFuncionCosto.ArqueologoFuncionCosto;
import frsf.cidisi.faia.exceptions.PrologConnectorException;

public class InterfazManager {
	
	// Numeracion de los tipos de busqueda disponibles
	public static final int BUSQUEDA_UBEME 		= 0;
	public static final int BUSQUEDA_SINUBEME 	= 1;
	public static final int BUSQUEDA_FUNCION 	= 2;
	public static final int BUSQUEDA_ESTRATEGIA	= 3;
	
	private static InterfazSimulator simulador;
	private static PanelSimulador window;
	private static Timer autoStep;
	private static int escenarioAct;
	private static int busquedaAct;
	
	public static void comenzarSimulador(int escenario, int busqueda) {
		escenarioAct = escenario;
		busquedaAct = busqueda;
		try {
			switch(busqueda){
			/*
			 * Realiza la busqueda que el arqueologo lleva a cabo sabiendo
			 * que el pirata Ubeme esta en la isla, robando. Ubeme roba
			 * seleccionando aleatoriamente una aldea y toma entre un 25%
			 * y un 75% del tesoro.
			 * Realiza una busqueda informada A* usando de funcion
			 * costo el balance entre $/Km en ir a una aldea y de Heuristica
			 * utiliza la distancia mas corta hacia la aldea Objetivo final.
			 */
			case BUSQUEDA_UBEME:
				ArqueologoConUbeme.ejecutar(escenario);
				break;
			/*
			 * Realiza la busqueda que el arqueologo lleva a cabo
			 * sin preocuparse de que el pirata Ubeme le robe tesoros.
			 * Realiza una busqueda informada A* usando de funcion
			 * costo el balance entre $/Km en ir a una aldea y de Heuristica
			 * utiliza la distancia mas corta hacia la aldea Objetivo final.
			 */
			case BUSQUEDA_SINUBEME:
				ArqueologoSinUbeme.ejecutar(escenario);
				break;
			/*
			 * El arqueologo realiza la busqueda basandose unicamente
			 * en la funcion de costo uniforme, donde utiliza como costo
			 * una relacion entre el $$ adquirible de una aldea y la distancia
			 * en Km en llegar a ella y lo hace hasta poder llegar al objetivo final.
			 */
			case BUSQUEDA_FUNCION:
				ArqueologoFuncionCosto.ejecutar(escenario);
				break;
			/*
			 * El arqueologo realiza la busqueda basandose en una estrategia
			 * de busqueda por profundidad. En este caso, importa mas el orden
			 * de las acciones a ejecutar y tecnicamente obtiene el camino con
			 * menos pasos posible.
			 */
			case BUSQUEDA_ESTRATEGIA:
				ArqueologoEstrategia.ejecutar(escenario);
				break;
			}
		} catch (PrologConnectorException e) {
			e.printStackTrace();
		}
	}
	
	public static void mostrarConfigurador() {
		window.cerrar();
		try {
			PanelConfigurar ventana = new PanelConfigurar();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	public static void setSimulator(InterfazSimulator sim) {
		simulador = sim;
		try {
			String busqueda = "Búsqueda";
			switch (busquedaAct) {
			case (BUSQUEDA_UBEME):
				busqueda += " A* con Ubeme.";
				break;
			case (BUSQUEDA_SINUBEME):
				busqueda += " A* sin Ubeme.";
				break;
			case (BUSQUEDA_FUNCION):
				busqueda += " con función costo.";
				break;
			case (BUSQUEDA_ESTRATEGIA):
				busqueda += " en profundidad.";
				break;
			}
			window = new PanelSimulador(escenarioAct, busqueda);
		} catch (Exception e) {
			e.printStackTrace();
		}
		autoStep = new Timer(1000, new ActionListener() {
		    public void actionPerformed(ActionEvent e) {
		        autoStep();
		    }
		});
	}
	
	public static void avanzar() {
		int res = simulador.avanzar();
		if (res == 1) {
			autoStep.stop();
			window.terminar();
			simulador.terminar();
		}
	}
	
	public static void mostrarAgentes(int posArq, int posPir) {
		if (posArq>=11)
			posArq = 5;
		window.mapa.moverAgentes(posArq, posPir);
	}
	
	public static void registrarEvento(String texto) {
		window.logPanel.addEvent(texto);
	}
	
	public static void actualizarDatos(int dist, int botin, double cont) {
		window.actualizarDatos(dist, botin, cont);
	}
	
	public static void actualizarInventario(int[] botin) {
		window.actualizarInventario(botin);
	}
	
	public static void actualizarIsla(int[][] tesoros) {
		window.actualizarIsla(tesoros);
	}
	
	public static void setAutoStep(boolean activar) {
		if (activar)
			autoStep.start();
		else
			autoStep.stop();
	}
	
	public static void autoStep() {
		if (autoStep.isRunning())
			avanzar();
	}

}
