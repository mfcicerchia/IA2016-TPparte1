package interfaz;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;


public class JLogPane extends JScrollPane {
	
	private JTextArea textArea;
	
	public JLogPane() {
		textArea = new JTextArea();
		textArea.setEditable(false);
		setViewportView(textArea);
	}
	
	public void reset() {
		textArea.setText("");
	}
	
	public void addEvent(String mensaje) {
		String texto = textArea.getText();
		texto += mensaje+"\n";
		textArea.setText(texto);
	}
}
