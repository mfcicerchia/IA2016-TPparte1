package ejercicio.auxiliar;

public class Aldeas {
	// Numeracion de las Aldeas
	  public static final int ARAGAEY 	= 0;
	  public static final int ASE 		= 1;
	  public static final int BRESOL 	= 2;
	  public static final int BULOVOE	= 3;
	  public static final int CABE		= 4;
	  public static final int CENEDE 	= 5;
	  public static final int ERGINTONE = 6;
	  public static final int ICAEDUR	= 7;
	  public static final int MIXOCU 	= 8;
	  public static final int PEREGAEY 	= 9;
	  public static final int VINIZAILE = 10;
	  public static final int CENEDEFIN = 11;
	  
	  /*
	   * Vector que mantiene la heuristica que usaria el agente
	   * (SOLO PARA BUSQUEDA INFORMADA CON/SIN UBEME)
	   */
	  private static int[] distanciasHeuristica;
	    
	  /*
	   * Matriz con las distancia desde una aldea a otra.
	   * Simula ser lo que el mapa informa.
	   */
	  private static final int[][] matrizDistancia;
	  static {
		  int[][] aux = new int[12][12];
		  for(int i=0; i<12; i++){
			  for(int j=0; j<12; j++){
				  aux[i][j] = -1;
			  }
		  }
		  aux[0][2]  = aux[2][0]  = 150;
		  aux[0][6]  = aux[6][0]  = 100;
		  aux[1][8]  = aux[8][1]  = 200;
		  aux[1][5]  = aux[5][1]  = 200;
		  aux[2][10] = aux[10][2] = 400;
		  aux[3][6]  = aux[6][3]  = 200;
		  aux[3][7]  = aux[7][3]  = 350;
		  aux[4][10] = aux[10][4] = 200;
		  aux[6][9]  = aux[9][6]  = 180;
		  aux[7][10] = aux[10][7] = 100;
		  aux[8][10] = aux[10][8] = 300;
		  aux[9][10] = aux[10][9] = 450;
		  aux[5][11] = aux[11][5] = 0;
		  matrizDistancia = aux;
		  distanciasHeuristica =  new int[]{1250,200,1100,1150,900,0,1330,800,400,1150,700,0};
	  }
	  
	  /** Devuelve la distancia desde A a B
	   * @param A int de la aldea "desde"
	   * @param B int de la aldea "hasta"
	   * @return distancia en int
	   */
	  public static int getDistanciaDesdeHasta(int A, int B){
		  return matrizDistancia[A][B];
	  }
	  
	  /** Devuelve todas las distancias desde A a todas las aldeas
	   * @param A int de la aldea "desde"
	   * @return int[] con las distancias desde A a todas las aldeas.
	   */
	  public static int[] getDistanciasDesde(int A){
		  return matrizDistancia[A];
	  }
	  
	  /** Devuelve las distancias
	   * @return int[][] matriz de distancias
	   */
	  public static int[][] getDistancias(){
		  return matrizDistancia;
	  }
	  
	  /**
	   * Devuelve el nombre de la aldea A
	   * @param A int de la aldea
	   * @return String nombre de la aldea
	   */
	  public static String aldeaNombre(int A){
		  String retorno = "Error";
		  switch(A){
		  case 0:
			  retorno = "ARAGAEY";
			  break;
		  case 1:
			  retorno = "ASE";
			  break;
		  case 2:
			  retorno = "BRESOL";
			  break;
		  case 3:
			  retorno = "BULOVOE";
			  break;
		  case 4:
			  retorno = "CABE";
			  break;
		  case 5:
			  retorno = "CENEDE";
			  break;
		  case 6:
			  retorno = "ERGINTONE";
			  break;
		  case 7:
			  retorno = "ICAEDUR";
			  break;
		  case 8:
			  retorno = "MIXOCU";
			  break;
		  case 9:
			  retorno = "PEREGAEY";
			  break;
		  case 10:
			  retorno = "VINIZAILE";
			  break;
		  case 11:
			  retorno = "CEDENE ~FIN~";
		  }
		  return retorno;
	  }
	  
	  /**
	   * Obtiene la heuristica desde la -aldea- hasta el objetivo final
	   * @param aldea int de la aldea
	   * @return int heuristica definida: distancia desde esa aldea hasta el objetivo final
	   */
	  public static int getHeuristicaDistancia(int aldea){
		  return distanciasHeuristica[aldea];
		  
	  }
	  
	  
}
