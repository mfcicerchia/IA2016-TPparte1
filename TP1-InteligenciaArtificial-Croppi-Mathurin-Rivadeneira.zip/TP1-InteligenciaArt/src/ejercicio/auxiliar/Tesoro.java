package ejercicio.auxiliar;

public class Tesoro {
	// Numeracion para los elementos
	public static final int MONEDA 		= 0;
	public static final int RUBI 		= 1;
	public static final int ANILLO 		= 2;
	public static final int DIAMANTE	= 3;
	public static final int COLGANTE	= 4;
	// Peso Kg. definido para cada elemento
	public static final double P_MONEDA 	= 0.1;
	public static final double P_RUBI 		= 0.02;
	public static final double P_ANILLO 	= 0.045;
	public static final double P_DIAMANTE 	= 0.07;
	public static final double P_COLGANTE 	= 0.02;
	// Valor en $ de cada elemento
	public static final int V_MONEDA 	= 100;
	public static final int V_RUBI 		= 50;
	public static final int V_ANILLO 	= 30;
	public static final int V_DIAMANTE 	= 90;
	public static final int V_COLGANTE 	= 15;
	
	public static int escenario = 0;
	public static final int[][] escenario1;
	public static final int[][] escenario2;
	public static final int[] valores1Heuristica;
	public static final int[] valores2Heuristica;
	static{
		escenario1 = new int[][]{
    			{100,20,80,300,550},
    			{20,50,70,100,60},
    			{80,80,70,20,200},
    			{250,120,20,150,300},
    			{160,250,170,60,120},
    			{220,300,130,400,280},
    			{300,400,280,80,150},
    			{400,200,300,400,250},
    			{350,350,240,150,350},
    			{100,400,500,450,500},
    			{50,150,200,50,150},
    			{0,0,0,0,0}};
		valores1Heuristica = new int[]{268850, 97600, 220200, 349650, 242100, 81100, 362150, 300050, 176050, 294300, 201300, 0};
		escenario2 = new int[][]{
				{500,200,150,500,400},
    			{300,400,500,200,150},
    			{400,500,250,300,550},
    			{150,350,100,100,250},
    			{250,150,350,400,350},
    			{100,300,400,400,400},
    			{300,400,50,100,80},
    			{50,150,300,80,150},
    			{50,400,300,500,250},
    			{200,150,200,300,400},
    			{500,200,150,300,250},
    			{0,0,0,0,0}};
		valores2Heuristica = new int[]{565500, 164250, 450000, 421450, 426500, 79000, 470450, 373200, 247000, 408750, 342250, 0};
	}
	
	public static int[][] getTesorosEscenario(){
		if(escenario==1){
			return escenario1;
		}
		return escenario2;
	}

	public static void setEscenario(int i) {
		escenario = i;
	}
	public static int getEscenario(){
		return escenario;
	}
	
	public static int getHeuristicaValor(int aldea){
		if(escenario==1){
			return valores1Heuristica[aldea];
		}
		return valores2Heuristica[aldea];
	}
}
