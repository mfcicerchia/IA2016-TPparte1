package ejercicio;

import interfaz.PanelConfigurar;
import java.awt.EventQueue;
import javax.swing.UIManager;

public class Main {

	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
					PanelConfigurar ventana = new PanelConfigurar();
				}
				catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

}
