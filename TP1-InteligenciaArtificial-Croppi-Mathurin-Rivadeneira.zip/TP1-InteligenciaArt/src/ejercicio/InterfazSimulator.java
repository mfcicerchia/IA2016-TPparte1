package ejercicio;

import interfaz.InterfazManager;

import java.util.Arrays;
import java.util.Vector;

import ejercicio.busqueda.base.ArqueologoEstado;
import ejercicio.busqueda.base.IslaEstado;
import frsf.cidisi.faia.agent.Action;
import frsf.cidisi.faia.agent.Agent;
import frsf.cidisi.faia.agent.GoalBasedAgent;
import frsf.cidisi.faia.agent.Perception;
import frsf.cidisi.faia.environment.Environment;
import frsf.cidisi.faia.simulator.SearchBasedAgentSimulator;
import frsf.cidisi.faia.simulator.events.EventType;
import frsf.cidisi.faia.simulator.events.SimulatorEventNotifier;

public class InterfazSimulator extends SearchBasedAgentSimulator {
	
	private boolean terminado;
	
	private Perception perception;
	private Action action;
	private GoalBasedAgent agent;

	public InterfazSimulator(Environment environment, Vector<Agent> agents) {
        super(environment, agents);
    }

    public InterfazSimulator(Environment environment, Agent agent) {
        this(environment, new Vector<Agent>(Arrays.asList(agent)));
        terminado = false;
    }
    
    public void start() {
        System.out.println("----------------------------------------------------");
        System.out.println("--- " + this.getSimulatorName() + " ---");
        System.out.println("----------------------------------------------------");
        System.out.println();
        InterfazManager.setSimulator(this);
    }
    
    public int avanzar() {
    	if (this.terminado)
    		return 1;
    	
        agent = (GoalBasedAgent) this.getAgents().firstElement();

    	System.out.println("------------------------------------");
        System.out.println("Sending perception to agent...");
        
        perception = this.getPercept();
        agent.see(perception);
        
        System.out.println("Perception: " + perception);
        System.out.println("Agent State: " + agent.getAgentState());
        System.out.println("Environment: " + environment);
        System.out.println("Asking the agent for an action...");
        
        action = agent.selectAction();

        if (action == null) {
        	this.terminado = true;
        }

        System.out.println("Action returned: " + action);
        System.out.println();
        InterfazManager.registrarEvento(action.toString());

        this.actionReturned(agent, action);
        
        ArqueologoEstado estado = (ArqueologoEstado) agent.getAgentState();
        IslaEstado ambiente = (IslaEstado) environment.getEnvironmentState();
        
        InterfazManager.mostrarAgentes(estado.getaldeaPos(), ambiente.getPirataPos());
        InterfazManager.actualizarInventario(estado.getbotin());
        InterfazManager.actualizarDatos(estado.getkmRecorridos(), estado.getValorBotin(), estado.getPesoBotin());
        InterfazManager.actualizarIsla(ambiente.gettesorosAldeas());
        
        if (this.agentSucceeded(action) || this.agentFailed(action)) {
        	this.terminado = true;
        }
        return 0;
    }
    
    public void terminar() {
    	// Check what happened, if agent has reached the goal or not.
        if (this.agentSucceeded(action)) {
            System.out.println("Agent has reached the goal!");
        } else {
            System.out.println("ERROR: The simulation has finished, but the agent has not reached his goal.");
        }
        // Leave a blank line
        System.out.println();
        // FIXME: This call can be moved to the Simulator class
        this.environment.close();
        // Launch simulationFinished event
        SimulatorEventNotifier.runEventHandlers(EventType.SimulationFinished, null);
    }
	
}
