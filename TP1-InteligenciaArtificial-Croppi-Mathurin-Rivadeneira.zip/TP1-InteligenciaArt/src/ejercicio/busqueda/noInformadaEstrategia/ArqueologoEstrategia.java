package ejercicio.busqueda.noInformadaEstrategia;

import ejercicio.InterfazSimulator;
import ejercicio.busqueda.base.Isla;
import frsf.cidisi.faia.exceptions.PrologConnectorException;
import frsf.cidisi.faia.simulator.SearchBasedAgentSimulator;

public class ArqueologoEstrategia {

    public static void ejecutar(int escenario) throws PrologConnectorException {
        Arqueologo agent = new Arqueologo();
        Isla environment = new Isla(escenario);

        InterfazSimulator simulator =
                new InterfazSimulator(environment, agent);
        
        simulator.start();
    }

}
