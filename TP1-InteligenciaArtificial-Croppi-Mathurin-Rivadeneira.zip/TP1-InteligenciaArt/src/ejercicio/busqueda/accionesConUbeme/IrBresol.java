package ejercicio.busqueda.accionesConUbeme;

import ejercicio.auxiliar.Aldeas;
import ejercicio.busqueda.base.ArqueologoEstado;
import ejercicio.busqueda.base.IslaEstado;
import frsf.cidisi.faia.agent.search.SearchAction;
import frsf.cidisi.faia.agent.search.SearchBasedAgentState;
import frsf.cidisi.faia.state.AgentState;
import frsf.cidisi.faia.state.EnvironmentState;

public class IrBresol extends SearchAction {

	static int destino = Aldeas.BRESOL;
	
    /**
     * This method updates a tree node state when the search process is running.
     * It does not updates the real world state.
     */
    @Override
    public SearchBasedAgentState execute(SearchBasedAgentState s) {
        ArqueologoEstado arqueologoEstado = (ArqueologoEstado) s;
        
        // Es destino vecino?
        if(arqueologoEstado.esVecino(destino)){
        	// Si, destino es vecino
        	// Ya paso una vez por destino?
        	if(arqueologoEstado.yaPasoUnaVez(destino)){
        		// Si, ya paso una vez por destino
        		// Hay otro vecino (ademas de destino) por el cual no pasaste?
        		if(arqueologoEstado.hayOtroVecinoNoVisitado(destino)){
        			// Si, hay otro vecino que no visite
        			// Entonces anda a ese vecino...
        			return null;
        		} else {
        			// No, ya visite todos los vecinos
        			// Ya pasaste dos veces por el destino?
        			if(arqueologoEstado.yaPasoDosVeces(destino)){
        				// Si, ya pase dos veces por este destino
        				// Ya llegaste a un limite. No podes ir a destino
        				return null;
        			} else {
        				// No, solo pase una sola vez por destino
        				// Entonces te permito pasar de nuevo.
        				// Update the agent state
        				arqueologoEstado.irA(destino);
        	            return arqueologoEstado;
        			}
        		}
        	} else {
        		// No, aun no pase por este destino
        		// Bueno, entonces pasa, divertite.
        		// Update the agent state
        		arqueologoEstado.irA(destino);
                return arqueologoEstado;
        	}
        }
        // No, destino no es vecino
        // Entonces raja de aca!
        return null;
    }

    /**
     * This method updates the agent state and the real world state.
     */
    @Override
    public EnvironmentState execute(AgentState ast, EnvironmentState est) {
        IslaEstado islaEstado = (IslaEstado) est;
        ArqueologoEstado arqueologoEstado = ((ArqueologoEstado) ast);
        
        // Es destino vecino?
        if(arqueologoEstado.esVecino(destino)){
        	// Si, destino es vecino
        	// Ya paso una vez por destino?
        	if(arqueologoEstado.yaPasoUnaVez(destino)){
        		// Si, ya paso una vez por destino
        		// Hay otro vecino (ademas de destino) por el cual no pasaste?
        		if(arqueologoEstado.hayOtroVecinoNoVisitado(destino)){
        			// Si, hay otro vecino que no visite
        			// Entonces anda a ese vecino...
        			return null;
        		} else {
        			// No, ya visite todos los vecinos
        			// Ya pasaste dos veces por el destino?
        			if(arqueologoEstado.yaPasoDosVeces(destino)){
        				// Si, ya pase dos veces por este destino
        				// Ya llegaste a un limite. No podes ir a destino
        				return null;
        			} else {
        				// No, solo pase una sola vez por destino
        				// Entonces te permito pasar de nuevo.
        				// Update the real world
                    	islaEstado.moverAgenteA(destino);
                    	islaEstado.atacaUbeme();
                        // Update the agent state
                		arqueologoEstado.irA(destino);
                		return islaEstado;
        			}
        		}
        	} else {
        		// No, aun no pase por este destino
        		// Bueno, entonces pasa, divertite.
        		// Update the real world
            	islaEstado.moverAgenteA(destino);
            	islaEstado.atacaUbeme();
                // Update the agent state
        		arqueologoEstado.irA(destino);
        		return islaEstado;
        	}
        } 
        // No, destino no es vecino
        // Entonces raja de aca!
        return null;
    }
    /**
     * This method returns the action cost.
     */
    @Override
    public Double getCost() {
        return (double) 0;
    }

    /**
     * This method is not important for a search based agent, but is essensial
     * when creating a calculus based one.
     */
    @Override
    public String toString() {
        return "Ir Bresol";
    }
}