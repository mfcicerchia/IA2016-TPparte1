package ejercicio.busqueda.accionesConUbeme;

import ejercicio.auxiliar.Aldeas;
import ejercicio.busqueda.base.ArqueologoEstado;
import ejercicio.busqueda.base.IslaEstado;
import frsf.cidisi.faia.agent.search.SearchAction;
import frsf.cidisi.faia.agent.search.SearchBasedAgentState;
import frsf.cidisi.faia.state.AgentState;
import frsf.cidisi.faia.state.EnvironmentState;

public class Terminar extends SearchAction {

    /**
     * This method updates a tree node state when the search process is running.
     * It does not updates the real world state.
     */
    @Override
    public SearchBasedAgentState execute(SearchBasedAgentState s) {
        ArqueologoEstado arqueologoEstado = (ArqueologoEstado) s;
        
        // Sos vecino de CenedeFin (Aldea ficticia final)?
        if(arqueologoEstado.esVecino(Aldeas.CENEDEFIN)){
        	// Si, mi vecino es CenedeFin
        	// ENTONCES ANDA AHI!
        	// Update the agent state
        	arqueologoEstado.irA(Aldeas.CENEDEFIN);
        	return arqueologoEstado;
        }
        // No, no soy vecino de CenedeFin
        // ENTONCES FUIRA! RAJA!
        return null;
    }

    /**
     * This method updates the agent state and the real world state.
     */
    @Override
    public EnvironmentState execute(AgentState ast, EnvironmentState est) {
        IslaEstado islaEstado = (IslaEstado) est;
        ArqueologoEstado arqueologoEstado = ((ArqueologoEstado) ast);
        // Sos vecino de CenedeFin (Aldea ficticia final)?
        if(arqueologoEstado.esVecino(Aldeas.CENEDEFIN)){
        	// Si, mi vecino es CenedeFin
        	// ENTONCES ANDA AHI!
        	// Update the real world
        	islaEstado.moverAgenteA(Aldeas.CENEDEFIN);
            // Update the agent state
			arqueologoEstado.irA(Aldeas.CENEDEFIN);
    		return islaEstado;
        }
        // No, no soy vecino de CenedeFin
        // ENTONCES FUIRA! RAJA!
        return null;
    }

    /**
     * This method returns the action cost.
     */
    @Override
    public Double getCost() {
        return (double) 0;
    }

    /**
     * This method is not important for a search based agent, but is essensial
     * when creating a calculus based one.
     */
    @Override
    public String toString() {
        return "Terminar";
    }
}