package ejercicio.busqueda.base;

import java.util.ArrayList;

import ejercicio.auxiliar.Aldeas;
import ejercicio.auxiliar.Tesoro;
import frsf.cidisi.faia.agent.Perception;
import frsf.cidisi.faia.agent.search.SearchBasedAgentState;

/**
 * Represent the internal state of the Agent.
 */
public class ArqueologoEstado extends SearchBasedAgentState {
	
	// Variables de estado
    private int aldeaPos;
    private int[] botin;
    private int kmRecorridos;
    private int[] vistaTesoro;
    // Para la busqueda
    private int[][] tesorosAldeas;
    // Utilizado en busqueda por funcion costo, y las informadas + heuristica.
    private double[][] costoValorPorKm;
    private ArrayList<Integer> recorrido;
	
    public ArqueologoEstado() {
        this.initState();
    }

    /**
     * This method clones the state of the agent. It's used in the search
     * process, when creating the search tree.
     */
    @Override
    public SearchBasedAgentState clone() {
        
    	ArqueologoEstado nuevoEstado = new ArqueologoEstado();
    	// Copiar posicion del agente.
    	int aldeaPos2 = this.getaldeaPos();
    	// Copiar el botin del agente.
    	int[] botin2 = new int[5];
    	for(int i=0; i<botin2.length; i++){
    		botin2[i] = this.getbotin()[i];
    	}
    	// Copiar los Km recorridos
    	int kmRecorridos2 = this.getkmRecorridos();
    	// Copiar el tesoro que de la aldea donde aun no realizo accion.
    	int[] vistaTesoro2 = new int[5];
    	for(int i=0; i<this.getvistaTesoro().length; i++){
    		vistaTesoro2[i] = this.getvistaTesoro()[i];
    	}
    	// Copiar la informacion que sabe de los tesoros de las otras aldeas.
    	int[][] tesorosAldeas2 = new int[12][5];
    	for(int i=0; i<this.gettesorosAldeas().length; i++){
    		for(int j=0; j<this.gettesorosAldeas()[i].length; j++){
    			tesorosAldeas2[i][j] = this.gettesorosAldeas()[i][j];
    		}
    	}
    	// Copiar el costo de sus movimientos de aldea en aldea (relacion $/Km)
    	double[][] costoValorPorKm2 = new double[12][12];
    	for(int i=0; i<this.getcostoValorPorKm().length; i++){
    		for(int j=0; j<this.getcostoValorPorKm()[i].length; j++){
    			costoValorPorKm2[i][j] = this.getcostoValorPorKm()[i][j];	
    		}
    	}
    	ArrayList<Integer> recorrido2 = new ArrayList<Integer>(this.getrecorrido());
    	
		nuevoEstado.setaldeaPos(aldeaPos2);
		nuevoEstado.setbotin(botin2);
		nuevoEstado.setkmRecorridos(kmRecorridos2);
		nuevoEstado.setvistaTesoro(vistaTesoro2);
		nuevoEstado.settesorosAldeas(tesorosAldeas2);
		nuevoEstado.setcostoValorPorKm(costoValorPorKm2);
		nuevoEstado.setrecorrido(recorrido2);
		
		return nuevoEstado;
    }

    /**
     * This method is used to update the Agent State when a Perception is
     * received by the Simulator.
     */
    @Override
    public void updateState(Perception p) {

        ArqueologoPerception arqueologoPercepcion = (ArqueologoPerception) p;
        // Agente ve y guarda lo que percibio (camara) del tesoro en la aldea donde esta
        this.setvistaTesoro(arqueologoPercepcion.getvistatesoro());
        // Agente ve y guarda lo que percibio (satelite) de los tesoros en las otras aldeas
        this.settesorosAldeas(arqueologoPercepcion.gettesorosaldeas());
        /*
         *  Agente calcula y estima los costos de sus movimientos en base a los
         *  tesoros en las otras aldeas y la distancia a la que esta de ellas.
         */
        this.setcostoValorPorKm(this.crearCostosValorPorKm());
    }

    /**
     * This method is optional, and sets the initial state of the agent.
     */
    @Override
    public void initState() {

    	this.setaldeaPos(Aldeas.ARAGAEY);
    	this.setbotin(new int[]{0,0,0,0,0});
    	this.setkmRecorridos(0);
    	this.setvistaTesoro(new int[]{0,0,0,0,0});
    	this.setcostoValorPorKm(new double[12][12]);
    	this.settesorosAldeas(new int[12][5]);
    	this.recorrido = new ArrayList<Integer>();
    }

    /**
     * This method returns the String representation of the agent state.
     */
    @Override
    public String toString() {
        String str = ">> ESTADO DEL AGENTE <<\n";
        str += "Arqueologo en aldea: " + this.getaldeaPos() + " (" + Aldeas.aldeaNombre(this.getaldeaPos()) + ")\n";
        str += "Botin: Monedas(" 
        	+ this.getbotin()[Tesoro.MONEDA] 
        	+ ") | Rubi(" 
        	+ this.getbotin()[Tesoro.RUBI]
        	+ ") | Anillo(" 
        	+ this.getbotin()[Tesoro.ANILLO]
        	+ ") | Diamante(" 
        	+ this.getbotin()[Tesoro.DIAMANTE]
        	+ ") | Colgante(" 
        	+ this.getbotin()[Tesoro.COLGANTE]
        	+ ")\n";
        str += "Valor ($$) total:\t$ " + this.getValorBotin() + "\n";
        str += "Peso (kg) en acoplado:\t" + this.getPesoBotin() + " Kg.\n";
        str += "Km Recorridos:\t" + this.getkmRecorridos() + "\n";
        return str;
    }

    /**
     * This method is used in the search process to verify if the node already
     * exists in the actual search.
     */
    @Override
    public boolean equals(Object obj) {
    	// Es una instancia distinta a ArqueologoEstado?
        if (!(obj instanceof ArqueologoEstado)) {
        	// No es igual
            return false;
        }
        
        // La posicion del agente es la misma?
        if (((ArqueologoEstado) obj).getaldeaPos() != this.getaldeaPos()){
        	// No. Es distinta.
        	return false;
        }
        
        // Si la posicion es la misma..
        // El botin.. es el mismo?
        for(int i=0; i<((ArqueologoEstado) obj).getbotin().length; i++){
        	if(((ArqueologoEstado) obj).getbotin()[i] != this.getbotin()[i]){
        		// Aca hay un valor que no es igual.. es distinto..
        		return false;
        	}
        }
        // Misma posicion con mismo botin..
        // Sospecho estado repetido..
        return true;
    }

    // The following methods are agent-specific:
   	
     public int getaldeaPos(){
        return aldeaPos;
     }
     public void setaldeaPos(int arg){
        aldeaPos = arg;
     }
     public int[] getbotin(){
        return botin;
     }
     public void setbotin(int[] arg){
        botin = arg;
     }
     public int getkmRecorridos(){
        return kmRecorridos;
     }
     public void setkmRecorridos(int arg){
        kmRecorridos = arg;
     }
     public int[] getvistaTesoro(){
        return vistaTesoro;
     }
     public void setvistaTesoro(int[] arg){
        vistaTesoro = arg;
     }
     public int[][] gettesorosAldeas(){
        return tesorosAldeas;
     }
     public void settesorosAldeas(int[][] arg){
        tesorosAldeas = arg;
     }
     public double[][] getcostoValorPorKm(){
         return costoValorPorKm;
     }
     public void setcostoValorPorKm(double[][] arg){
    	 costoValorPorKm = arg;
     }
     public ArrayList<Integer> getrecorrido(){
    	 return recorrido;
     }
     public void setrecorrido(ArrayList<Integer> arg){
    	recorrido = arg;
     }

     /**
      * Devuelve si el parametro -aldea- es vecino de la ciudad donde se posiciona
      * actualmente el agente.
      * @param aldea int de la aldea destino que quiero saber si es vecino
      * @return true si es vecino / false si no lo es
      */
     public boolean esVecino(int aldea){
    	 if(Aldeas.getDistancias()[this.getaldeaPos()][aldea] >= 0) return true;
    	 else return false; 
     }
     
     /**
      * Devuelve el valor en $$ que el agente tiene en su botin.
      * @return int del valor del botin en comodos $$
      */
     public int getValorBotin(){
    	 int retorno = 0;
    	 retorno += this.getbotin()[Tesoro.MONEDA]*Tesoro.V_MONEDA +
    			 this.getbotin()[Tesoro.RUBI]*Tesoro.V_RUBI +
    			 this.getbotin()[Tesoro.ANILLO]*Tesoro.V_ANILLO +
    			 this.getbotin()[Tesoro.DIAMANTE]*Tesoro.V_DIAMANTE +
    			 this.getbotin()[Tesoro.COLGANTE]*Tesoro.V_COLGANTE;
    	 return retorno;
     }
     
     /**
      * Devuelve el peso en Kg que el agente tiene en su acoplado.
      * @return double del peso en Kg que el agente lleva.
      */
     public double getPesoBotin(){
    	 double retorno = 0;
    	 retorno += this.getbotin()[Tesoro.MONEDA]*Tesoro.P_MONEDA +
    			 this.getbotin()[Tesoro.RUBI]*Tesoro.P_RUBI +
    			 this.getbotin()[Tesoro.ANILLO]*Tesoro.P_ANILLO +
    			 this.getbotin()[Tesoro.DIAMANTE]*Tesoro.P_DIAMANTE +
    			 this.getbotin()[Tesoro.COLGANTE]*Tesoro.P_COLGANTE;
    	 return retorno;
     }
     
     /**
      * Devuelve el valor en $$ que el agente tiene en su botin.
      * @return int del valor del botin en comodos $$
      */
     public double getPesoTesoroAldea(){
    	 double retorno = 0;
    	 retorno += this.getvistaTesoro()[Tesoro.MONEDA]*Tesoro.P_MONEDA +
    			 this.getvistaTesoro()[Tesoro.RUBI]*Tesoro.P_RUBI +
    			 this.getvistaTesoro()[Tesoro.ANILLO]*Tesoro.P_ANILLO +
    			 this.getvistaTesoro()[Tesoro.DIAMANTE]*Tesoro.P_DIAMANTE +
    			 this.getvistaTesoro()[Tesoro.COLGANTE]*Tesoro.P_COLGANTE;
    	 return retorno;
     }
     
     /**
      * Toma el tesoro donde el arqueologo se encuentra ubicado.
      * Modifica la vista del tesoro y lo que sabe que habia en esa aldea.
      */
     public void tomarTesoro(){
    	 for(int i=0; i<this.getbotin().length; i++){
    		 this.getbotin()[i] += this.getvistaTesoro()[i];
    		 this.getvistaTesoro()[i]=0;
    		 this.gettesorosAldeas()[this.getaldeaPos()][i]=0;
    	 }
    	 return;
     }
     
     /**
      * Modifica la posicion del agente. Agrega los Km que le lleva ir al destino.
      * Previamente se tiene que asegurar que -destino- sea vecino de donde se
      * situa el agente.
      * @param destino int de la aldea a donde se mueve.
      */
     public void irA(int destino){
    	 this.getrecorrido().add(this.getaldeaPos());
    	 this.setkmRecorridos(this.getkmRecorridos()+Aldeas.getDistancias()[this.getaldeaPos()][destino]);
    	 this.setaldeaPos(destino);
     }
     
    /**
     * Informa si el agente ya paso una vez por la aldea -destino-.
     * Lo verifica chequeando el recorrido que fue haciendo.
     * @param destino int de la aldea destino
     * @return true si ya paso una vez / false en caso contrario
     */
     public boolean yaPasoUnaVez(int destino){
    	 int contador = 0;
    	 for(int i=0; i<this.getrecorrido().size(); i++){
    		 if(this.getrecorrido().get(i) == destino){
    			 contador++;
    		 }
    	 }
    	 if(contador!=0){
    		 return true;
    	 }
    	 return false;
     }
     
     /**
      * Informa si el agente ya paso dos veces por la aldea -destino-.
      * Lo verifica chequeando el recorrido que fue haciendo.
      * @param destino int de la aldea destino
      * @return true si ya paso dos veces / false en caso contrario
      */
     public boolean yaPasoDosVeces(int destino){
    	 int contador = 0;
    	 for(int i=0; i<this.getrecorrido().size(); i++){
    		 if(this.getrecorrido().get(i) == destino){
    			 contador++;
    		 }
    	 }
    	 if(contador==2){
    		 return true;
    	 }
    	 return false;
     }
     
     /**
      * Informa si el agente aun le queda pasar por algun vecino.
      * Se ayuda sabiendo cual fue el recorrido previo a preguntarse.
      * @param aldeaExceptuada int de la aldea a la cual se le exceptua la pregunta.
      * @return true si hay vecinos que aun no paso por ahi / false si ya paso por todos
      */
     public boolean hayOtroVecinoNoVisitado(int aldeaExceptuada){
    	 // Visite todos los vecinos (false)
    	 boolean retorno = false;
    	 // Aca guardo los vecinos de la aldea donde estoy parado actualmente
    	 ArrayList<Integer> vecinos = new ArrayList<Integer>();
    	 for(int i=0; i<Aldeas.getDistancias()[this.getaldeaPos()].length; i++){
    		 if(Aldeas.getDistancias()[this.getaldeaPos()][i]>0){
    			 if(aldeaExceptuada!=i){
    				 // Esta aldea es vecino y no es la aldeaExceptuada.
    				 // La guardo!
    				 vecinos.add(i);
    			 }
    		 }
    	 }
    	 for(int i=0; i<this.getrecorrido().size(); i++){
    		 // De los vecinos que encontre, algunos ya visite antes?
    		 if(vecinos.contains(this.getrecorrido().get(i))){
    			 // Si
    			 // Entonces quitalos de esta lista
    			 vecinos.remove(this.getrecorrido().get(i));
    		 }
    	 }
    	 // Me quedaron vecinos en esa lista?
    	 if(!vecinos.isEmpty()){
    		 // Si
    		 // Entonces hay vecinos que aun no visite. Devolver.
    		 retorno = true;
    	 }
    	 return retorno;
     }
     
     /**
      * Informa si hay tesoros en esta aldea donde el agente se encuentra actualmente
      * @return true si hay tesoros en esta aldea / false en caso contrario
      */
     public boolean hayTesoro(){
    	 int suma = 0; 
    	 for(int i=0; i<this.getvistaTesoro().length; i++){
    		 suma += this.getvistaTesoro()[i];
    	 }
    	 if(suma>0){
    		 return true;
    	 } 
    	 return false;
     }
     
     /**
      * Para la busqueda. Informa si en la aldea actual (nodo actual de busqueda), hay tesoro estimado.
      * No se puede usar la vista de la camara durante la busqueda, esa vista
      * la puedo actualizar cada vez que percibo.
      * @return true si hay tesoro (segun lo que me dijo el satelite) / false en caso contrario
      */
     public boolean hayTesoroEstimado(){
    	 int suma = 0;
    	 for(int i=0; i<this.gettesorosAldeas()[this.getaldeaPos()].length; i++){
    		 suma += this.gettesorosAldeas()[this.getaldeaPos()][i];
    	 }
    	 if(suma>0){
    		 return true;
    	 } 
    	 return false;
     }
     
     /**
      * Para la busqueda. Informa en la aldea actual (nodo actual de busqueda) el peso del tesoro estimado.
      * No se puede usar la vista de la camara durante la busqueda, esa vista
      * la puedo actualizar cada vez que percibo.
      * @return true si hay tesoro (segun lo que me dijo el satelite) / false en caso contrario
      */
     public double getPesoEstimado(){
    	 double retorno = 0;
    	 retorno += this.gettesorosAldeas()[this.getaldeaPos()][Tesoro.MONEDA]*Tesoro.P_MONEDA +
    			 this.gettesorosAldeas()[this.getaldeaPos()][Tesoro.RUBI]*Tesoro.P_RUBI +
    			 this.gettesorosAldeas()[this.getaldeaPos()][Tesoro.ANILLO]*Tesoro.P_ANILLO +
    			 this.gettesorosAldeas()[this.getaldeaPos()][Tesoro.DIAMANTE]*Tesoro.P_DIAMANTE +
    			 this.gettesorosAldeas()[this.getaldeaPos()][Tesoro.COLGANTE]*Tesoro.P_COLGANTE;
    	 return retorno;
     }
     
     /**
      * Para la busqueda. Toma de la aldea actual (nodo actual de busqueda) el peso del tesoro estimado.
      * No se puede usar la vista de la camara durante la busqueda, esa vista
      * la puedo actualizar cada vez que percibo.
      * Ademas no es que toma realmente el tesoro, esto es como que lo simula, para expandir el arbol de
      * busqueda. Mientras se realiza el arbol de busqueda, nunca se persibe, y el agente tiene que
      * armar el arbol de busqueda en base a su estado.
      */
     public void tomarTesoroEstimado(){
    	 for(int i=0; i<this.gettesorosAldeas()[this.getaldeaPos()].length; i++){
    		 this.getbotin()[i] += this.gettesorosAldeas()[this.getaldeaPos()][i];
    		 this.gettesorosAldeas()[this.getaldeaPos()][i] = 0;
    	 }
    	 return;
     }
     
     /**
      * Crea la matriz de costos $$/Km. Esta matriz relaciona el tesoro en una aldea con la
      * distancia que lleva ir a esta. Por cada Km, se obtendria cierto $$. El agente, de usar
      * este dato, iria por aquella que mas valor tenga. Se arma en base a lo que percibe de los
      * tesoros en otras aldeas y con las distancias que el mapa le informa.
      * @return double
      */
     public double[][] crearCostosValorPorKm(){
    	 // Obtengo las distancias. Gracias mapa!
    	 int[][] aldeasDistancias = Aldeas.getDistancias();
    	 // Obtengo los valores en $$ de cada aldea
    	 int[] valoresAldeas = new int[aldeasDistancias.length];
    	 for(int i=0; i<aldeasDistancias.length; i++){
    		 valoresAldeas[i] = this.gettesorosAldeas()[i][Tesoro.MONEDA]*Tesoro.V_MONEDA 
    		        	+ this.gettesorosAldeas()[i][Tesoro.RUBI]*Tesoro.V_RUBI 
    		        	+ this.gettesorosAldeas()[i][Tesoro.ANILLO]*Tesoro.V_ANILLO
    		        	+ this.gettesorosAldeas()[i][Tesoro.DIAMANTE]*Tesoro.V_DIAMANTE 
    		        	+ this.gettesorosAldeas()[i][Tesoro.COLGANTE]*Tesoro.V_COLGANTE;
    	 }
    	 
    	 double[][] matrizCosto = new double[aldeasDistancias.length][aldeasDistancias.length];
    	 for(int i=0;i<aldeasDistancias.length; i++){
    		 for(int j=0; j<aldeasDistancias[i].length; j++){
    			 // Si la distancia es cero (consecuencia de la aldea ficticia FIN)
    			 if(aldeasDistancias[i][j]==0){
    				 // El costo es 0
    				 matrizCosto[i][j] = 0;
    			 } // Si la distancia entre i y i es >0
    			 else if(aldeasDistancias[i][j]>0){
    				 // Calcular la relacion del valor $$ de aldea j con la distancia de ir desde i hasta j
    				 matrizCosto[i][j] = (((double)valoresAldeas[j])/((double)aldeasDistancias[i][j]));
    			 } else {
    				 // No hay distancia desde i hasta j, costo no existente.
    				 matrizCosto[i][j] = -1;
    			 }
    		 }
    	 }
    	 return matrizCosto;
     }

     /**
      * Devuelve el costo $$/Km de ir desde la aldea -desde- hasta -hasta
      * @param desde int de la aldea desde
      * @param hasta int de la aldea hasta
      * @return double el costo en $$/Km
      */
     public double getCosto(int desde, int hasta){
    	 return this.getcostoValorPorKm()[desde][hasta];
     }
}

