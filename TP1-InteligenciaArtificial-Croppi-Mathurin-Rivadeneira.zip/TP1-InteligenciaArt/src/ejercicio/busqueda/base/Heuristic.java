package ejercicio.busqueda.base;

import ejercicio.auxiliar.Aldeas;
import ejercicio.auxiliar.Tesoro;
import frsf.cidisi.faia.solver.search.IEstimatedCostFunction;
import frsf.cidisi.faia.solver.search.NTree;

/**
 * This class allows to define a function to be used by any
 * informed search strategy, like A Star or Greedy.
 */
public class Heuristic implements IEstimatedCostFunction {

    /**
     * It returns the estimated cost to reach the goal from a NTree node.
     * La heuristica elegida es la relacion entre el beneficio en $$ 
     * obtenible por el camino en Km mas corto..
     */
    @Override
    public double getEstimatedCost(NTree node) {
        ArqueologoEstado arqueologoEstado = (ArqueologoEstado) node.getAgentState();
        // Una accion como Tomar tesoro no me provee la heuristica
        if(node.getAction().toString() == "Tomar Tesoro"){
    		return 0;
    	} else {
    		int posicion = arqueologoEstado.getaldeaPos();
    		if(posicion == Aldeas.CENEDEFIN || posicion == Aldeas.CENEDE){
    			return (0);
    		}
    		return ( -(((double)Tesoro.getHeuristicaValor(posicion))/((double)Aldeas.getHeuristicaDistancia(posicion))) );
    	}
    }
}
