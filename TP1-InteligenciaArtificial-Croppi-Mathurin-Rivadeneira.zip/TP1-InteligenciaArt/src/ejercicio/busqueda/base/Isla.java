package ejercicio.busqueda.base;

import frsf.cidisi.faia.agent.Action;
import frsf.cidisi.faia.environment.Environment;

public class Isla extends Environment {

    public Isla(int escenario) {
        this.environmentState = new IslaEstado(escenario);
    }

    public IslaEstado getEnvironmentState() {
        return (IslaEstado) super.getEnvironmentState();
    }

    /**
     * This method is called by the simulator. Given the Agent, it creates
     * a new perception reading, for example, the agent position.
     * @param agent
     * @return A perception that will be given to the agent by the simulator.
     */
    @Override
    public  ArqueologoPerception getPercept() {
        // Create a new perception to return
         ArqueologoPerception percepcion = new ArqueologoPerception();
		
		// Set the perceptions sensors
        int posicionArqueologo = this.getEnvironmentState().getaldeaPos();
        
        percepcion.settesorosaldeas(this.getTesorosAldeas());
        percepcion.setvistatesoro(this.getVistaTesoro(posicionArqueologo));
         
        // Return the perception
        return percepcion;
    }


	public String toString() {
        return environmentState.toString();
    }

    
    public boolean agentFailed(Action actionReturned) {
        IslaEstado envState =this.getEnvironmentState();
        return false;
    }

    // The following methods are agent-specific:
    
    /**
     * Devuelve una matriz donde [aldea] devuelve el valor en $$$
     * de ese tesoro en esa aldea. Si la aldea tiene 0 en $$$,
     * no hay tesoro en la aldea.
     * @return
     */
    
    private int[][] getTesorosAldeas() {
		return ((IslaEstado) this.environmentState).gettesorosAldeas();
	}
    
    /**
     * Devuelve la cantidad de tesoros en la aldea en vector int[5]
     * @param aldea
     * @return
     */
	private int[] getVistaTesoro(int aldea) {
		return ((IslaEstado) this.environmentState).getVistaTesoro(aldea);
	} 
	
	
}
