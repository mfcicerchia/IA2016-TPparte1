

package ejercicio.busqueda.base;

import ejercicio.auxiliar.Aldeas;
import frsf.cidisi.faia.agent.search.GoalTest;
import frsf.cidisi.faia.state.AgentState;

public class ArqueologoObjetivo extends GoalTest {

    @Override
    public boolean isGoalState (AgentState arqueologoEstado) {
    	
    	// Tu posicion es en la aldea CenedeFin?
        if  (((ArqueologoEstado)arqueologoEstado).getaldeaPos() == Aldeas.CENEDEFIN){
        	// Si
        	// FELICIDADES! ESTAS EN EL OBJETIVO!
        	return true;
        	} 
        return false;
	}
}