package ejercicio.busqueda.base;

import ejercicio.auxiliar.Aldeas;
import frsf.cidisi.faia.agent.Agent;
import frsf.cidisi.faia.agent.Perception;
import frsf.cidisi.faia.environment.Environment;

public class ArqueologoPerception extends Perception {

	// Sensores
	private int[] vistatesoro; // Camara
	private int[][] tesorosaldeas; // Satelite
	
    public  ArqueologoPerception() {
    }

    public ArqueologoPerception(Agent agent, Environment environment) {
        super(agent, environment);
    }

    /**
     * This method is used to setup the perception.
     */
    @Override
    public void initPerception(Agent agentIn, Environment environmentIn) {
    	return;
    }
    
    @Override
    public String toString() {
        StringBuffer str = new StringBuffer();
        str.append(">> PERCEPCION DEL AGENTE <<\n");
        str.append("[Camara] Tesoro capturable: ");
        for(int i=0; i<this.getvistatesoro().length; i++){
        	str.append(this.getvistatesoro()[i]);
        	if(i!=4) str.append(" | ");
        }
        str.append("\n");
        str.append("[Satelite] Tesoros estimado en Aldeas:\n");
        for(int i=0; i<11; i++){
        	str.append(Aldeas.aldeaNombre(i) + ":\t\t");
        	for(int j=0; j<5; j++){
        		str.append(this.gettesorosaldeas()[i][j] + " | ");
        	}
        	str.append("\n");
        }
        return str.toString();
    }

    // The following methods are agent-specific:
	
     public int[] getvistatesoro(){
        return vistatesoro;
     }
     public void setvistatesoro(int[] arg){
        this.vistatesoro = arg;
     }
     public int[][] gettesorosaldeas(){
        return tesorosaldeas;
     }
     public void settesorosaldeas(int[][] arg){
        this.tesorosaldeas = arg;
     }
   
}
