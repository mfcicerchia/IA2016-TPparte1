package ejercicio.busqueda.base;

import java.util.Random;

import ejercicio.auxiliar.Aldeas;
import ejercicio.auxiliar.Tesoro;
import frsf.cidisi.faia.state.EnvironmentState;

/**
 * This class represents the real world state.
 */
public class IslaEstado extends EnvironmentState {
	
	// Variables de la isla estado
    private int aldeaPos;
    private int pirataPos;
    private int[][] tesorosAldeas;
	
    public IslaEstado(int escenario) {
    	Tesoro.setEscenario(escenario);
    	int[][] escenarioTesoros = Tesoro.getTesorosEscenario();
    	int[][] aux = new int[escenarioTesoros.length][escenarioTesoros[0].length];
    	for(int i=0; i<escenarioTesoros.length; i++){
    		for (int j=0; j<escenarioTesoros[i].length; j++){
    			aux[i][j] = escenarioTesoros[i][j];
    		}
    	}
    	this.settesorosAldeas(aux);
    	
        this.initState();
    }

    /**
     * This method is used to setup the initial real world.
     */
    @Override
    public void initState() {
    	this.setaldeaPos(Aldeas.ARAGAEY);
    	this.setpirataPos(-1);
    }

    /**
     * String representation of the real world state.
     */
    @Override
    public String toString() {
        String str = "";
        str += "\n>> ESTADO ISLA <<\n";
        str += "Posicion Agente: " + this.getaldeaPos() + " (" + Aldeas.aldeaNombre(this.getaldeaPos()) + ") \n";
        str += "Tesoros aldeas:\n";
        for(int i=0; i<this.gettesorosAldeas().length; i++){
        	str += Aldeas.aldeaNombre(i) + "\t ";
        	for(int j=0; j<this.gettesorosAldeas()[i].length; j++){
        		str += this.gettesorosAldeas()[i][j];
        		if (j!=4) str += " | ";
        	}
        	str += "\n";
        }
        return str;
    }

    // The following methods are agent-specific:
	
     public int getaldeaPos(){
        return aldeaPos;
     }
     public void setaldeaPos(int arg){
        aldeaPos = arg;
     }
     public int[][] gettesorosAldeas(){
        return tesorosAldeas;
     }
     public void settesorosAldeas(int[][] arg){
        tesorosAldeas = arg;
     }
    
     /**
      * Devuelve el tesoro que hay en -aldea-
      * @param aldea int de la aldea a la que quiero que me de los tesoros
      * @return int[] con los tesoros en esa aldea.
      */
	public int[] getVistaTesoro(int aldea) {
		int[] tesorosAldea = new int[5];
		for(int i=0; i<this.gettesorosAldeas()[aldea].length; i++){
			tesorosAldea[i] = this.gettesorosAldeas()[aldea][i];
		}
		return tesorosAldea;
	}
	
	/**
	 * Modifica la posicion del agente a -aldea-
	 * @param aldea int de la aldea a donde se movio el agente.
	 */
	public void moverAgenteA(int aldea){
		this.setaldeaPos(aldea);
	}
	
	/**
	 * Quita todo el tesoro de la aldea donde esta el agente.
	 */
	public void agenteTomaTesoro(){
		for(int i=0; i<this.gettesorosAldeas()[this.getaldeaPos()].length; i++){
			this.gettesorosAldeas()[this.getaldeaPos()][i] = 0;
		}
	}
	
	/**
	 * Pregunta si hay tesoros en -aldea-
	 * @param aldea int de la aldea a la cual pregunto si hay tesoros
	 * @return true si hay tesoros / false en caso contrario
	 */
	public boolean sinTesorosEnAldea(int aldea){
		for(int i=0; i<this.gettesorosAldeas()[aldea].length;i++){
			if(this.gettesorosAldeas()[aldea][i]>0){
				return false;
			}
		}
		return true;
	}
	
	/**
	 * Simula la accion del pirata UBEME sobre la isla.
	 * Ataca a una aldea donde seguramente hay tesoros, y quita entre un
	 * 25% y un 75% de su tesoros.
	 */
	public void atacaUbeme(){
		Random rand = new Random();
		int aldeaRandom = rand.nextInt(10);	//0 + (int)(Math.random() * ((10 + 0) + 1));
		while(this.sinTesorosEnAldea(aldeaRandom)){
			aldeaRandom = rand.nextInt(10);
		}
		System.out.println("UBEME ATACO " + Aldeas.aldeaNombre(aldeaRandom) + "!!!");
		this.setpirataPos(aldeaRandom);
		for(int j=0;j<this.gettesorosAldeas()[aldeaRandom].length; j++){
			double random = Math.random();
			while(random > 0.75 && random < 0.25){
				random = Math.random();
			}
			this.gettesorosAldeas()[aldeaRandom][j] = 
					(int) Math.round(this.gettesorosAldeas()[aldeaRandom][j] -
							this.gettesorosAldeas()[aldeaRandom][j]*random);
		}
	}
	/**
	 * Setea la posicion del pirata en -aldea-
	 * @param aldea int de la aldea donde esta el pirata
	 */
	public void setpirataPos(int aldea){
		this.pirataPos = aldea;
	}
	
	/**
	 * Devuelve la posicion del pirata
	 * @return int de la aldea donde se posiciona el pirata
	 */
	public int getPirataPos(){
		return pirataPos;
	}
	
}

