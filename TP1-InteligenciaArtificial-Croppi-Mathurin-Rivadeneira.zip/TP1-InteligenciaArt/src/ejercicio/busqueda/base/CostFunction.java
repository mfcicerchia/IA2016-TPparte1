package ejercicio.busqueda.base;

import frsf.cidisi.faia.solver.search.IStepCostFunction;
import frsf.cidisi.faia.solver.search.NTree;

/**
 * This class can be used in any search strategy like
 * Uniform Cost.
 */
public class CostFunction implements IStepCostFunction {

    /**
     * This method calculates the cost of the given NTree node.
     * EXPLICACION DEL COSTO: Faia utiliza estos metodos y elige la accion en base al camino
     * de acciones nodos cuyo costo acumulado sea el mas chico. Debido a como esta planteado,
     * a nosotros nos interesa que fuera al reves, o sea, que elija el camino que mas costo
     * acumulado le brinde. La funcion costo se basa en una relacion entre el valor en $$ y
     * la distancia en Km de ir a una aldea. Es preferible ir a una aldea cuyo $$/Km sea mayor
     * (Recorro menos KM y obtengo mayor $$)
     * <p>
     * Dado que mientras mas alto sea este valor, mas preferible seria ir a esta aldea.
     * Pero faia interpreta que mientras mas alto este valor, peor va a ser ir a esta aldea.
     * Por lo tanto definimos que
     * <p>
     * - El costo de cada accion sea un numero negativo: Para poder enga�ar a arbol de expansion,
     * ya que mientras mas grande sea el valor, en negativo, mas chico sera, y el arbol elijira esa
     * accion por tener mayor valor negativo. (VER DOCUMENTACION)
     * <p>
     * - Tomar tesoro siempre sera la accion que mas recompensa de (accion preferida)
     * <p>
     * - Moverse de una aldea a otra tendra de costo el $$/Km pero en negativo. Mientra mas
     * chico sea el numero (en negativo) mejor, mas preferible sera ir a esta aldea.
     */
    @Override
    public double calculateCost(NTree node) {
    	// El nodo donde estoy, la accion tomada es tomar tesoro?
    	if(node.getAction().toString() == "Tomar Tesoro"){
    		// Si
    		// Es mi accion preferida, elegi esta siempre por encima de las demas.
    		return -1500;
    	} else {
    		// No
    		// Entonces debe ser una accion de moverse a otra aldea.. consegui el costo
    		int aldeaDesde = ((ArqueologoEstado)node.getParent().getAgentState()).getaldeaPos();
    		int aldeaHasta =  ((ArqueologoEstado)node.getAgentState()).getaldeaPos();
    		if(((ArqueologoEstado)node.getAgentState()).getCosto(aldeaDesde, aldeaHasta) >= 0){
    			// Le metemos costo negativo para que faia eliga el de mayor beneficio!
    			return (double) -((ArqueologoEstado)node.getAgentState()).getCosto(aldeaDesde, aldeaHasta);
    		}
    	}
    	return 0;
    }
}
