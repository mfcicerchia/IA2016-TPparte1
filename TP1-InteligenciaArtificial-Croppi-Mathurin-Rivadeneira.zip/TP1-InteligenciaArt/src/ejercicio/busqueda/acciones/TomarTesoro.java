package ejercicio.busqueda.acciones;

import ejercicio.busqueda.base.ArqueologoEstado;
import ejercicio.busqueda.base.IslaEstado;
import frsf.cidisi.faia.agent.search.SearchAction;
import frsf.cidisi.faia.agent.search.SearchBasedAgentState;
import frsf.cidisi.faia.state.AgentState;
import frsf.cidisi.faia.state.EnvironmentState;

public class TomarTesoro extends SearchAction {

    /**
     * This method updates a tree node state when the search process is running.
     * It does not updates the real world state.
     */
    @Override
    public SearchBasedAgentState execute(SearchBasedAgentState s) {
        ArqueologoEstado arqueologoEstado = (ArqueologoEstado) s;
        
        // Hay tesoro en la isla donde estas ubicado?
        // Y si tomaras ese tesoro, �No excedes tu limite de 450 Kg de acoplado?
        if(arqueologoEstado.hayTesoroEstimado() 
        		&& (arqueologoEstado.getPesoBotin() + arqueologoEstado.getPesoEstimado()) <= (double) 450){
        	// Hay tesoro, y puedo cargar con su peso!
        	// Entonces chiquito, tomalo y hacete millonario!
        	// Update the agent state
        	arqueologoEstado.tomarTesoroEstimado();
        	return arqueologoEstado;
        }
        // No hay tesoro... o hay tesoro, pero no puedo cargarlo
        // Segui de largo, arqueologo pobre... >:C
        return null;
    }

    /**
     * This method updates the agent state and the real world state.
     */
    @Override
    public EnvironmentState execute(AgentState ast, EnvironmentState est) {
        IslaEstado islaEstado = (IslaEstado) est;
        ArqueologoEstado arqueologoEstado = ((ArqueologoEstado) ast);
        
        // Hay tesoro en la isla donde estas ubicado?
        // Y si tomaras ese tesoro, �No excedes tu limite de 450 Kg de acoplado?
        if (arqueologoEstado.hayTesoro() == true
        		&& (arqueologoEstado.getPesoBotin() + arqueologoEstado.getPesoTesoroAldea())<=(double)450) {
        	// Hay tesoro, y puedo cargar con su peso!
        	// Entonces chiquito, tomalo y hacete millonario!
        	// Update the agent state
            // Update the real world
        	islaEstado.agenteTomaTesoro();
            // Update the agent state
        	arqueologoEstado.tomarTesoro();
            return islaEstado;
        }
        // No hay tesoro... o hay tesoro, pero no puedo cargarlo
        // Segui de largo, arqueologo pobre... >:C
        return null;
    }

    /**
     * This method returns the action cost.
     */
    @Override
    public Double getCost() {
        return new Double(0);
    }

    /**
     * This method is not important for a search based agent, but is essensial
     * when creating a calculus based one.
     */
    @Override
    public String toString() {
        return "Tomar Tesoro";
    }
}